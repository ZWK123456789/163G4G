/**
 * 
 */
package com.qhit.utilsTest;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Test;

import com.qhit.Orcl_To1.bean.Dept;
import com.qhit.Orcl_To1.util.DBUtils;

/**
 * @author ZWK
 *2018年3月16日上午11:03:07
 *TODO
 */
public class DButilTest {
 private Connection con ;
 private PreparedStatement ps ;
 private ResultSet rs ;
 private Dept dept;
	@Test
	public void test() {
		con = DBUtils.getConnection();
		String sql = "select * from dept";
		try {
			ps =con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs != null &&rs.next()){
				dept = new Dept();
				dept.setDeptno(rs.getString("deptno"));
				dept.setDname(rs.getString("dname"));
				dept.setLoc(rs.getString("loc"));
				System.out.println(dept.toString());
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
