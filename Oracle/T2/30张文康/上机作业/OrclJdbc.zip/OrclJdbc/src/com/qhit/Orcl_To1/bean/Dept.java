/**
 * 
 */
package com.qhit.Orcl_To1.bean;

/**
 * @author ZWK
 *2018年3月16日上午10:56:42
 *TODO
 */
public class Dept {
     private String deptno;
     private String dname;
     private String loc;
	/**
	 * @return the deptno
	 */
	public String getDeptno() {
		return deptno;
	}
	/**
	 * @param deptno the deptno to set
	 */
	public void setDeptno(String deptno) {
		this.deptno = deptno;
	}
	/**
	 * @return the dname
	 */
	public String getDname() {
		return dname;
	}
	/**
	 * @param dname the dname to set
	 */
	public void setDname(String dname) {
		this.dname = dname;
	}
	/**
	 * @return the loc
	 */
	public String getLoc() {
		return loc;
	}
	/**
	 * @param loc the loc to set
	 */
	public void setLoc(String loc) {
		this.loc = loc;
	}
	/**
	 * 
	 */
	public Dept() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param deptno
	 * @param dname
	 * @param loc
	 */
	public Dept(String deptno, String dname, String loc) {
		super();
		this.deptno = deptno;
		this.dname = dname;
		this.loc = loc;
	}
     public String toString() {
    	 return this.deptno+"||"+this.dname+"||"+this.loc;
     }
}
