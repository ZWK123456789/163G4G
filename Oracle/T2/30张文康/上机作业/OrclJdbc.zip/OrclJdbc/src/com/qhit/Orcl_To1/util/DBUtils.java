/**
 * 
 */
package com.qhit.Orcl_To1.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author ZWK
 *2018年3月16日上午10:51:29
 *TODO
 */
public class DBUtils {
  private static Connection con;
  private static String driver = "oracle.jdbc.driver.OracleDriver";
  private static String url = "jdbc:oracle:thin:@localhost:1521:orcl";
  private static String user = "scott";
  private static String password = "tiger";
  
  public static Connection getConnection () {
	 try {
		Class.forName(driver);
		con = DriverManager.getConnection(url, user, password);
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  return con;
  }
}
